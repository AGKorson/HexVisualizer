﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HexVisualizer;
using Microsoft.VisualStudio.DebuggerVisualizers;

namespace MyTestConsole {
    internal class TestConsole {
        static void Main(string[] args) {
            byte[] bTest = new byte[52];
            for (int i = 0;  i < bTest.Length; i++) {
                bTest[i] = (byte)(100-i);
            }
            VisualizerDevelopmentHost visualizerHost = new VisualizerDevelopmentHost(bTest, typeof(DebuggerSide));
            visualizerHost.ShowVisualizer();
        }
    }
}
