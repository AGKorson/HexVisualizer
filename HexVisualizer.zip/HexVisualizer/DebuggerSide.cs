﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.DebuggerVisualizers;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

[assembly: System.Diagnostics.DebuggerVisualizer(
typeof(HexVisualizer.DebuggerSide),
typeof(VisualizerObjectSource),
Target = typeof(byte[]),
Description = "Byte Array Hex Visualizer")]

namespace HexVisualizer {
    [Obsolete]
    public class DebuggerSide : DialogDebuggerVisualizer {
        protected override void Show(IDialogVisualizerService windowService, IVisualizerObjectProvider objectProvider) {
            try {
                HexViewer hexViewer = new HexViewer();
                byte[] bArray;

                using (Stream opData = objectProvider.GetData()) {
                    BinaryFormatter bf = new BinaryFormatter();
                    bArray = bf.Deserialize(opData) as byte[];
                }
                hexViewer.Show();
                MessageBox.Show("Array size is " + bArray.Length);
            }
            catch (Exception ex) {
                MessageBox.Show("Error in visualizer: " + ex.Message);
            }
        }
        public static void TestShowVisualizer(object objectToVisualize) {
            VisualizerDevelopmentHost visualizerHost = new VisualizerDevelopmentHost(objectToVisualize, typeof(DebuggerSide));
            visualizerHost.ShowVisualizer();
        }
    }
}
